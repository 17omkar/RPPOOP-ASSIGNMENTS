from curses import flash
import pickle
from click import UUID
from flask import Flask, redirect, render_template, request, jsonify, url_for
import requests
import json
from dotenv import load_dotenv
import os
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
# from flask_wtf import wtforms
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, IntegerField
from wtforms.validators import InputRequired, Length, ValidationError, Email
from flask_bcrypt import Bcrypt
import time
# current_user = "";
image_sample_link = "https://thumbs.dreamstime.com/b/random-apartment-bandung-west-java-209842157.jpg"
base_maps_link = "https://www.google.com/maps/place/?q=place_id:"
# image_base_url = https://maps.googleapis.com/maps/api/place/photo
#   ?maxwidth=400
#   &photo_reference=Aap_uEA7vb0DDYVJWEaX3O-AtYp77AaswQKSGtDaimt3gt7QCNpdjp1BkdM6acJ96xTec3tsV_ZJNL_JP-lqsVxydG3nh739RE_hepOOL05tfJh2_ranjMadb3VoBYFvF0ma6S24qZ6QJUuV6sSRrhCskSBP5C1myCzsebztMfGvm7ij3gZT
#   &key=YOUR_API_KEY



# details_base_url = url = "https://maps.googleapis.com/maps/api/place/details/json?place_id=ChIJN1t_tDeuEmsRUsoyG83frY4&key=YOUR_API_KEY"


GOOGLE_MAPS_LINK_BASE_URL = "https://www.google.com/maps/place/?q=place_id:"
class Hostel:
    def __init__(self, name, address, rating, photo_reference, place_id):
        self.name = name
        self.address = address
        self.rating = rating
        self.photo_reference = photo_reference
        self.place_id = place_id

    def get_place_id(self):
        return self.place_id
    
    def get_name(self):
        return self.name
    
    def get_address(self):
        return self.address
    
    def get_rating(self):
        return self.rating
    
    def get_photo_reference(self):
        return self.photo_reference
    
    


def configure():
    load_dotenv()







app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SECRET_KEY'] = "thisisasecretkey"
db = SQLAlchemy(app)
app.app_context().push()
bcrypt = Bcrypt(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'



class Student(db.Model, UserMixin):
    mis = db.Column(db.Integer, primary_key=True, unique=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(100), nullable=False)
    contact = db.Column(db.Integer, nullable=False)

    def get_id(self):
        return (self.mis)
    
class Admin(db.Model, UserMixin):
    username = db.Column(db.String(100), primary_key=True, unique=True)
    password = db.Column(db.String(100), nullable=False)
    
    def get_id(self):
        return (self.username)
    
class StudentApplication(db.Model):

    ID = db.Column(db.Integer, nullable=False, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    mis = db.Column(db.Integer, nullable=False)
    category = db.Column(db.String(100), nullable=False)
    gender = db.Column(db.String(100), nullable=False)
    cgpa = db.Column(db.Float, nullable=False)
    branch = db.Column(db.String(100), nullable=False)
    selected = db.Column(db.Boolean, nullable=False)
    confirmed = db.Column(db.Boolean, nullable=False)
    round = db.Column(db.Integer, nullable=False)
    selected_in = db.Column(db.Integer, nullable=False)

class Round(db.Model):
    round_no = db.Column(db.Integer, primary_key=True, unique=True)   
    # resultdeclared = db.Column(db.Boolean, nullable=False)
    roundcompleted = db.Column(db.Boolean, nullable=False)





@login_manager.user_loader
def load_user(user_id):
    if(type(user_id) == str):
        return Admin.query.get(user_id)
    else:
        return Student.query.get(int(user_id))


class StudentRegisterForm(FlaskForm):
    mis = IntegerField('mis', validators=[InputRequired()], render_kw={"placeholder": "Enter your MIS"})
    name = StringField('name', validators=[InputRequired(), Length(min=4, max=100)], render_kw={"placeholder": "Enter your name"})
    email = StringField('email', validators=[InputRequired(), Email(message='Invalid email'), Length(max=100)], render_kw={"placeholder": "Enter your email"})
    password = PasswordField('password', validators=[InputRequired(), Length(min=8, max=100)], render_kw={"placeholder": "Enter your password"})
    contact = IntegerField('contact', validators=[InputRequired()], render_kw={"placeholder": "Enter your contact number"})
    submit = SubmitField('Sign Up')

    def validate_mis(self, mis):
        existing_mis = Student.query.filter_by(mis=mis.data).first()

        if existing_mis:
            raise ValidationError('That MIS is already registered.')
        
class StudentLoginForm(FlaskForm):
    mis = IntegerField('mis', validators=[InputRequired()], render_kw={"placeholder": "Enter your MIS"})
    password = PasswordField('password', validators=[InputRequired(), Length(min=8, max=100)], render_kw={"placeholder": "Enter your password"})
    submit = SubmitField('Login')

class AdminLoginForm(FlaskForm):
    username = StringField('username', validators=[InputRequired(), Length(min=4, max=100)], render_kw={"placeholder": "Enter your username"})
    password = PasswordField('password', validators=[InputRequired(), Length(min=8, max=100)], render_kw={"placeholder": "Enter your password"})
    submit = SubmitField('Login')

class AdminRegisterForm(FlaskForm):
    username = StringField('username', validators=[InputRequired(), Length(min=4, max=100)], render_kw={"placeholder": "Enter your username"})
    password = PasswordField('password', validators=[InputRequired(), Length(min=8, max=100)], render_kw={"placeholder": "Enter your password"})
    submit = SubmitField('Sign Up')

    def validate_username(self, username):
        existing_username = Admin.query.filter_by(username=username.data).first()

        if existing_username:
            raise ValidationError('That username is already registered.')
        








configure()




GOOGLE_PLACES_API_KEY = os.getenv('GOOGLE_PLACES_API_KEY')
# query = input("Enter search query: ")

# url = f"https://maps.googleapis.com/maps/api/place/textsearch/json?query=hostels%20near%2{query}&key={GOOGLE_PLACES_API_KEY}"

    

# payload = {}
# headers = {}

# response = requests.request("GET", url, headers=headers, data=payload)

# print(response.json().get('results'))

    
# for i in data.get('results'):
#     h = Hostel(i.get('name'), i.get('formatted_address'), i.get('rating'), i.get('photos')[0].get('photo_reference'), i.get('place_id'))

#     Hostels.append(h) 



# sample.close()



@app.route('/')# for i in data.get('results'):
#     h = Hostel(i.get('name'), i.get('formatted_address'), i.get('rating'), i.get('photos')[0].get('photo_reference'), i.get('place_id'))
def slash():
    return redirect(url_for('allotmenthome'))
#     Hostels.append(h) 



# sample.close()
@app.route('/home')
def home():
    # for i in Hostels:
    #     print(i.get_name())
    #     print(i.get_address())
    #     print(i.get_rating())
    #     print(i.get_photo_reference())
    #     print(i.get_place_id())
    #     print("\n\n")
    return render_template('index.html')
# @app.route('/recommend/<string:search_query>')
# def recommend(search_query):
#     return render_template('recommendhostels.html', hostels=Hostels, search_query=search_query)
@app.route('/recommend', methods=['POST', 'GET'])

def recommendhostels():
    if request.method == 'POST':
        Hostels = []
        print("POST")
        print(request.form.get('college_name'))
        query = request.form.get('college_name')
        url = f"https://maps.googleapis.com/maps/api/place/textsearch/json?query=hostels%20near%2{query}&key={GOOGLE_PLACES_API_KEY}"

    

        payload = {}
        headers = {}

        response = requests.request("GET", url, headers=headers, data=payload)


        print(response.json().get('results'))

        for i in response.json().get('results'):
            h = Hostel(i.get('name'), i.get('formatted_address'), i.get('rating'), "", i.get('place_id'))

            Hostels.append(h) 

        
        # query = ""

        # sample =  open('sample.json', "r")
        # data = json.load(sample)


        # for i in data.get('results'):
        #     h = Hostel(i.get('name'), i.get('formatted_address'), i.get('rating'), "", GOOGLE_MAPS_LINK_BASE_URL+ i.get('place_id'))

        #     Hostels.append(h) 



        # sample.close()

        return render_template('recommendhostels.html', hostels=Hostels, search_query=request.form.get('college_name'))
    return render_template('recommendhostels.html')


@app.route("/allotmenthome")
def allotmenthome():
    return render_template('allotmenthome.html')

@app.route("/allotmenthome/studentlogin", methods=['POST', 'GET'])
def studentlogin():
    form = StudentLoginForm()
    if form.validate_on_submit():
        student = Student.query.filter_by(mis=form.mis.data).first()
        if student and bcrypt.check_password_hash(student.password, form.password.data):
            login_user(student)
            # load_user(student.mis)
            return redirect(url_for('studenthome'))
        else:
            flash('Login Unsuccessful. Please check MIS and password', 'danger')
    return render_template('studentlogin.html', form=form)

@app.route('/studenthome', methods=['POST', 'GET'])
@login_required
def studenthome():
    student_application = StudentApplication.query.filter_by(mis=current_user.mis).first()
    rounds=Round.query.all()
    applied = []
    print(rounds)
    # i = 0
    for round in rounds:
        exists =  StudentApplication.query.filter_by(round=round.round_no, mis=current_user.mis).first()is not None
        # print(student_application)
        # print(exists, current_user.mis)
        # print(exists.mis)
        if exists:
            applied.append(1)
        else:
            applied.append(0)
        
    # if(student_application):
    #     return render_template('studenthome.html', current_username=current_user.name, applied=applied)

    print(applied)
    return render_template('studenthome.html', current_username=current_user.name, applied=applied, rounds=rounds, leng=len(rounds))
    

@app.route("/allotmenthome/studentsignup", methods=['POST', 'GET'])
def studentsignup():
    form = StudentRegisterForm()
    if(form.validate_on_submit()):
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        student = Student(name=form.name.data, email=form.email.data, password=hashed_password, mis=form.mis.data, contact=form.contact.data)
        db.session.add(student)
        db.session.commit()
        # flash('Your account has been cresated! You are now able to log in', 'success')
        print("yes")
        return redirect(url_for('studentlogin'))
    return render_template('studentsignup.html', form=form)

@app.route("/studenthome/studentlogout", methods=['POST', 'GET'])
def studentlogout():
    logout_user()
    return redirect(url_for('allotmenthome'))

@app.route("/adminhome", methods=['POST', 'GET'])
@login_required
def adminhome():
    rounds = Round.query.order_by(Round.round_no.desc())
    
    # round = rounds[len(rounds)-1]
    round_no = 0
    if rounds:
        max = 0
        for round in rounds:
            if(round.round_no > max):
                temp = round
                max = round.round_no
        round_no = max
    else:
        round_no = 1

    if temp.roundcompleted == 0:
        round_no=-1
    rounds = Round.query.all()
    print(round_no)
    return render_template('adminhome.html', round=round_no+1, rounds=rounds)


@app.route("/allotmenthome/adminlogin", methods=['POST', 'GET'])
def adminlogin():
    form = AdminLoginForm()
    if form.validate_on_submit():
        admin = Admin.query.filter_by(username=form.username.data).first()
        if admin and (admin.password == form.password.data):
            login_user(admin)
            # load_user(student.mis)
            return redirect(url_for('adminhome'))
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')
    return render_template('adminlogin.html', form=form)


@app.route("/allotmenthome/adminlogout", methods=['POST', 'GET'])
def adminlogout():
    logout_user()
    return redirect(url_for('allotmenthome'))

@app.route("/allotmenthome/adminsignup", methods=['POST', 'GET'])
def adminsignup():
    form = AdminRegisterForm()
    if(form.validate_on_submit()):
        # hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        admin = Admin(username=form.username.data, password=form.password.data)
        db.session.add(admin)
        db.session.commit()
        # flash('Your account has been cresated! You are now able to log in', 'success')
        return redirect(url_for('adminlogin'))
    return render_template('adminsignup.html', form=form)

@app.route("/studenthome/applyforhostel/<int:round>", methods=['POST', 'GET'])
def applyforhostel(round):
    if(request.method == 'GET'):
        return render_template('applyform.html', round=round)
    
    else:
        studentapplication = StudentApplication(name=current_user.name, mis=current_user.mis, gender=request.form.get('gender'), category=request.form.get('category'), cgpa=request.form.get('cgpainp'), branch=request.form.get('branch'), selected=False, confirmed=False,round=round, ID=int(time.time()), selected_in=-1)
        db.session.add(studentapplication)
        db.session.commit()
        return redirect(url_for('studenthome'))
        # print(request.form.get('gender'))

OPEN = 1


@app.route("/adminhome/viewapplications/<int:round>", methods=['POST', 'GET'])
def viewapplications(round):
    studentapplications = StudentApplication.query.order_by(StudentApplication.branch, 
    StudentApplication.gender, StudentApplication.category, StudentApplication.cgpa.desc()).filter_by(round=round)
    
    # if round.round_no:
    #     pass
    # else:
    #     round.round_no = 1
    return render_template('viewapplications.html', studentapplications=studentapplications, round=round, vieewresults=0)


@app.route("/studenthome/viewapplicationstatus/<int:round>")
def viewapplicationstatus(round):
    student_application = StudentApplication.query.filter_by(mis=current_user.mis, round=round).first()
    round = Round.query.filter_by(round_no=round).first()
    return render_template("viewapplicationstatus.html", student_application=student_application, round=round)



@app.route("/adminhome/declareresults/<int:round>")
def declareresults(round):
    studentapplications = StudentApplication.query.order_by(StudentApplication.branch, 
    StudentApplication.gender, StudentApplication.category, StudentApplication.cgpa.desc())
    Round.query.filter_by(round_no = round).first().roundcompleted = 1
    # print(round)
    db.session.commit()
    for studentapplication in studentapplications:
        count = StudentApplication.query.filter_by(branch=studentapplication.branch, category=studentapplication.category, gender=studentapplication.gender,round=round ,selected=True).count()

        if(count < 3):
            studentapplication.selected = True
            db.session.commit()   

    return redirect(url_for('adminhome'))

@app.route("/adminhome/resetresults/<int:round>")
def resetresults(round):
    studentapplications = StudentApplication.query.all()
    Round.query.filter_by(round_no = round).first().roundcompleted = 0
    for studentapplication in studentapplications:
        studentapplication.selected = False
        studentapplication.confirmed = False
        db.session.commit()
    
    return redirect(url_for('viewapplications', round=round))

@app.route("/studenthome/viewapplicationstatus/accept/<int:round>")
def accept(round):
    studentapplication = StudentApplication.query.filter_by(mis=current_user.mis, round=round).first()
    if studentapplication.selected:
        studentapplication.confirmed = True
        studentapplication.selected_in = round
        db.session.commit()
    return redirect(url_for('studenthome'))
@app.route("/studenthome/viewapplicationstatus/reject/<int:round>")
def reject():
    studentapplication = StudentApplication.query.filter_by(mis=current_user.mis).first()
    if studentapplication.selected:
        studentapplication.confirmed = False
        db.session.commit()
    return redirect(url_for('studenthome'))


@app.route("/adminhome/releaseform/<int:round>")
def releaseform(round):
    round_no = round
    round = Round(round_no=round_no, roundcompleted=0)
    db.session.add(round)
    db.session.commit()

    student_applications = StudentApplication.query.filter_by(round=round_no-1)
    filtered = []

    for student_application in student_applications:
        if(student_application.selected == True and student_application.confirmed == True):
            student_application.round = round_no
            db.session.commit()
        elif(student_application.selected==False):
            student_application.round = round_no
            db.session.commit()   

    return redirect(url_for('adminhome'))


@app.route("/adminhome/viewresults/<int:round>")
def viewresult(round):
    confirmed = StudentApplication.query.filter_by(selected_in=round)
    # print(confirmed[0].name)
    return render_template("viewapplications.html", studentapplications=confirmed, round=round, viewresults=1)

Branch_CIVIL = 0
Branch_Computer = 1
Branch_ELECTRICAL = 2
Branch_ENTC = 3
Branch_INSTRUMENTATION = 4
Branch_Manufacturing = 5
Branch_Mechanical = 6
Branch_Metallurgy = 7
Category_EWS = 8
Category_JK = 9
Category_NT = 10	
Category_OBC = 11
Category_Open	= 12
Category_SC = 13
Category_ST =14
@app.route("/predict", methods=['POST', 'GET'])
def predict():
    if request.method == 'POST':
        print("yes")
        with open('model_pickle', 'rb') as f:
            mp = pickle.load(f)

        arr = [0, 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
        arr[0] = int(request.form.get('batch'))
        factor1 = 0
        factor2=0
        if request.form.get('branch') == 'Branch_CIVIL':
            arr[Branch_CIVIL] = 1
            
        elif request.form.get('branch') == 'Branch_Computer':
            arr[Branch_Computer] = 1
            factor1 = 1.25
        elif request.form.get('branch') == 'Branch_ELECTRICAL':
            arr[Branch_ELECTRICAL] = 1
        elif request.form.get('branch') == 'Branch_ENTC':
            arr[Branch_ENTC] = 1
        elif request.form.get('branch') == 'Branch_INSTRUMENTATION':
            arr[Branch_INSTRUMENTATION] = 1
        elif request.form.get('branch') == 'Branch_Manufacturing':
            arr[Branch_Manufacturing] = 1
        elif request.form.get('branch') == 'Branch_Mechanical':
            arr[Branch_Mechanical] = 1
        elif request.form.get('branch') == 'Branch_Metallurgy':
            arr[Branch_Metallurgy] = 1
        
        if request.form.get('category') == 'Category_EWS':
            arr[Category_EWS] = 1
        elif request.form.get('category') == 'Category_JK':
            arr[Category_JK] = 1
        elif request.form.get('category') == 'Category_NT':
            arr[Category_NT] = 1
        elif request.form.get('category') == 'Category_OBC':
            arr[Category_OBC] = 1
        elif request.form.get('category') == 'Category_Open':
            arr[Category_Open] = 1
            factor2 = 1.25
        elif request.form.get('category') == 'Category_SC':
            arr[Category_SC] = 1
        elif request.form.get('category') == 'Category_ST':
            arr[Category_ST] = 1
        
        prediction = mp.predict([arr])[0] + factor1 + factor2
        print(prediction)
        
        return render_template('predictresult.html',round=request.form.get('round'), prediction=prediction, batch=arr[0], branch=request.form.get('branch'), category=request.form.get('category'))

    else:
        return render_template('predict.html')


if __name__ == "__main__":
    app.run(debug=True, port=8000)
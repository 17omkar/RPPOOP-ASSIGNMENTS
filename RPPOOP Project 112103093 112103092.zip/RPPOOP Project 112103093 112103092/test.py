import time 


for i in range(10):
    print(int(time.time()))
    time.sleep(1)